/**
 * Copyright 2017-present, Facebook, Inc. All rights reserved.
 *
 * This source code is licensed under the license found in the
 * LICENSE file in the root directory of this source tree.
 *
 * Messenger Platform Quick Start Tutorial
 *
 * This is the completed code for the Messenger Platform quick start tutorial
 *
 * https://developers.facebook.com/docs/messenger-platform/getting-started/quick-start/
 *
 * To run this code, you must do the following:
 *
 * 1. Deploy this code to a server running Node.js
 * 2. Run `npm install`
 * 3. Update the VERIFY_TOKEN
 * 4. Add your PAGE_ACCESS_TOKEN to your environment vars
 *
 */

"use strict";
const PAGE_ACCESS_TOKEN = process.env.PAGE_ACCESS_TOKEN;
const APP_ID = process.env.APP_ID;
const firebase = require("firebase");
// Required for side-effects
require("firebase/firestore");

firebase.initializeApp({
  apiKey: process.env.API_KEY,
  authDomain: process.env.AUTH_DOMAIN,
  projectId: process.env.PROJECT_ID
});

var db = firebase.firestore();
var language;
var modeHayWord;
var word;
var def;
var wordType;
var synonym;
var censored;
var featureHayWord = [];
// Imports dependencies and set up http server
const request = require("request"),
  express = require("express"),
  body_parser = require("body-parser"),
  app = express();

let menuPayload = {
  attachment: {
    type: "template",
    payload: {
      template_type: "generic",
      elements: [
        {
          title: "HayWord",
          image_url:
            "https://res.cloudinary.com/dzrwauiut/image/upload/v1603631463/HayWord_qj0hzv.png",
          subtitle: "enrich your vocabulary through a fun way",
          buttons: [
            {
              type: "postback",
              title: "🕹 Play",
              payload: "PLAY_HAYWORD"
            }
          ]
        }
      ]
    }
  }
};

app.set("view engine", "ejs");
app.use(body_parser.json()); // creates express http server

app.use(express.static("public"));

// Sets server port and logs message on success
app.listen(process.env.PORT || 1337, () => console.log("webhook is listening"));

// Accepts POST requests at /webhook endpoint
app.post("/webhook", (req, res) => {
  // Parse the request body from the POST
  let body = req.body;

  // Check the webhook event is from a Page subscription
  if (body.object === "page") {
    body.entry.forEach(function(entry) {
      // Gets the body of the webhook event
      let webhook_event = entry.messaging[0];
      console.log(webhook_event);

      // Get the sender PSID
      let sender_psid = webhook_event.sender.id;
      console.log("Sender ID: " + sender_psid);

      // Check if the event is a message or postback and
      // pass the event to the appropriate handler function
      if (webhook_event.message) {
        handleMessage(sender_psid, webhook_event.message);
      } else if (webhook_event.postback) {
        handlePostback(sender_psid, webhook_event.postback);
      }
    });
    // Return a '200 OK' response to all events
    res.status(200).send("EVENT_RECEIVED");
  } else {
    // Return a '404 Not Found' if event is not from a page subscription
    res.sendStatus(404);
  }
});

// Accepts GET requests at the /webhook endpoint
app.get("/webhook", (req, res) => {
  /** UPDATE YOUR VERIFY TOKEN **/
  const VERIFY_TOKEN = process.env.VERIFY_TOKEN;

  // Parse params from the webhook verification request
  let mode = req.query["hub.mode"];
  let token = req.query["hub.verify_token"];
  let challenge = req.query["hub.challenge"];

  // Check if a token and mode were sent
  if (mode && token) {
    // Check the mode and token sent are correct
    if (mode === "subscribe" && token === VERIFY_TOKEN) {
      // Respond with 200 OK and challenge token from the request
      console.log("WEBHOOK_VERIFIED");
      res.status(200).send(challenge);
    } else {
      // Responds with '403 Forbidden' if verify tokens do not match
      res.sendStatus(403);
    }
  }
});

app.get("/setProfile/:userID", (req, res, next) => {
  db.doc(`users/${req.params.userID}`)
    .get()
    .then(docSnapshot => {
      if (docSnapshot.exists) {
        language = docSnapshot.data().language;
        res.render("setProfile", {
          appId: APP_ID,
          title: "Setting Profile",
          lang: language
        });
      } else {
        db.collection("users")
          .doc(`${req.params.userID}`)
          .set({
            id: req.params.userID,
            language: "-"
          })
          .then(function() {
            res.render("setProfile", {
              appId: APP_ID,
              title: "Setting Profile",
              lang: "-"
            });
          })
          .catch(function(error) {
            console.error("Error writing document: ", error);
          });
      }
    });
});

app.post("/setProfile", (req, res) => {
  console.log(req.body);
  db.doc(`users/${req.body.id}`)
    .update({
      language: `${req.body.lang}`
    })
    .then(function() {
      language = req.body.lang;
      callSendAPI(req.body.id, {
        text: "Your Profile has Updated"
      }).then(() => {
        callSendAPI(req.body.id, {
          text:
            'Type "menu" for accessing our feature or type "Translate <Word or Sentence that you want to translate to your language>"'
        });
      });

      res.status(200).end();
    });
});

async function translate(text, lang) {
  return new Promise((resolve, reject) => {
    var options = {
      method: "GET",
      url: "https://just-translated.p.rapidapi.com/",
      qs: { text: text, lang_from: "en", lang_to: lang },
      headers: {
        "x-rapidapi-host": "just-translated.p.rapidapi.com",
        "x-rapidapi-key": process.env.RAPID_API_KEY,
        useQueryString: true
      }
    };

    request(options, function(error, response, body) {
      if (error) reject(error);
      let res = JSON.parse(body);

      resolve(res.text[0]);
    });
  });
}

function getWord() {
  return new Promise((resolve, reject) => {
    var options = {
      method: "GET",
      url: "https://wordsapiv1.p.rapidapi.com/words/",
      qs: {
        random: "true",
        lettersMin: "4",
        lettersMax: "8",
        frequencyMin: "4.05",
        frequencyMax: "8.03",
        hasDetails: "definitions,partofspeech,synonyms"
      },
      headers: {
        "x-rapidapi-host": "wordsapiv1.p.rapidapi.com",
        "x-rapidapi-key": process.env.RAPID_API_KEY,
        useQueryString: true
      }
    };

    request(options, function(error, response, body) {
      if (error) reject(error);

      const bodyParse = JSON.parse(body);
      console.log(bodyParse);
      const word = bodyParse.word;
      const def = bodyParse.results[0].definition || "";
      const wordType = bodyParse.results[0].partOfSpeech || "";
      const synonym = bodyParse.results[0].synonyms[0] || "";
      resolve([word, def, wordType, synonym]);
    });
  });
}

async function handleMessage(sender_psid, received_message) {
  let response;

  // Checks if the message contains text
  if (received_message.text) {
    // Create the payload for a basic text message, which
    // will be added to the body of our request to the Send API
    console.log(received_message.nlp.entities);
    const objNlp = received_message.nlp.entities;

    if (
      objNlp.intent &&
      objNlp.intent[0].value == "translate" &&
      objNlp.intent[0].confidence > 0.8 &&
      objNlp.phrase_to_translate[0].confidence > 0.8
    ) {
      language = language
        ? language
        : await db
            .doc(`users/${sender_psid}`)
            .get()
            .then(docSnapshot => {
              if (docSnapshot.exists) {
                console.log("language from here");
                return docSnapshot.data().language;
              }
            });

      let tr = await translate(objNlp.phrase_to_translate[0].value, language);

      response = {
        text: tr
      };
      return callSendAPI(sender_psid, response);
    } else if (received_message.text.toLowerCase() == "menu") {
      response = menuPayload;
      return callSendAPI(sender_psid, response);
    }

    if (modeHayWord) {
      if (received_message.quick_reply) {
        if (received_message.quick_reply.payload == "WORD_TYPE") {
          response = { text: wordType };
        } else if (received_message.quick_reply.payload == "DEFINITION") {
          response = { text: def };
        } else if (received_message.quick_reply.payload == "SYNONYM") {
          response = { text: synonym };
        } else if (received_message.quick_reply.payload == "SURR") {
          featureHayWord = []
          return callSendAPI(sender_psid, { text: "the Answer is "+word }).then(() =>
            callSendAPI(sender_psid, {text: 'don\'t give up 💪'})
          );
        }
        return callSendAPI(sender_psid, response);
      } else if (received_message.text) {
        if (received_message.text.toLowerCase() == word) {
          modeHayWord = false;
          featureHayWord = []
          response = { text: "Right Answer " };
          return callSendAPI(sender_psid, response);
        } else {
          response = { text: censored, quick_replies: featureHayWord };
          return callSendAPI(sender_psid, { text: "Wrong Answer" }).then(() =>
            callSendAPI(sender_psid, response, "RESPONSE")
          );
        }
      }
    }
  }
}

function handlePostback(sender_psid, received_postback) {
  let response;
  // Get the payload for the postback
  let payload = received_postback.payload;
  if (payload === "MULAI") {
    response = {
      attachment: {
        type: "template",
        payload: {
          template_type: "button",
          text:
            "Hello, welcome to HayWord. please set your profile before access our features",
          buttons: [
            {
              type: "web_url",
              url: "https://hayword.glitch.me/setProfile/" + sender_psid,
              title: "Set Profile",
              webview_height_ratio: "compact",
              messenger_extensions: true
            }
          ]
        }
      }
    };
    callSendAPI(sender_psid, response);
  } else if (payload === "PLAY_HAYWORD") {
    modeHayWord = true;
    getWord().then(data => {
      console.log(data)
      word = data[0];
      def = data[1];
      wordType = data[2];
      synonym = data[3];

      var regex = /(?<!^).(?!$)/g;
      censored = word.replace(regex, " _ ");
      console.log("censoredWord : " + censored);

      if (wordType != "") {
        featureHayWord.push({
          content_type: "text",
          title: "Type of Word",
          payload: "WORD_TYPE"
        });
      }
      if (def != "") {
        featureHayWord.push({
          content_type: "text",
          title: "Definition",
          payload: "DEFINITION"
        });
      }
      if (synonym != "") {
        featureHayWord.push({
          content_type: "text",
          title: "Synonym",
          payload: "SYNONYM"
        });
      }
      featureHayWord.push({
        content_type: "text",
        title: "🥺 Surrender",
        payload: "SURR"
      });

      response = { text: censored, quick_replies: featureHayWord };

      // Send the message to acknowledge the postback
      return callSendAPI(sender_psid, response, "RESPONSE");
    });
  }
}

function callSendAPI(sender_psid, response, msg_type) {
  return new Promise((resolve, reject) => {
    // Construct the message body
    let request_body;

    if (msg_type) {
      request_body = {
        recipient: {
          id: sender_psid
        },
        messaging_type: "RESPONSE",
        message: response
      };
    } else {
      request_body = {
        recipient: {
          id: sender_psid
        },
        message: response
      };
    }

    // Send the HTTP request to the Messenger Platform
    request(
      {
        uri: "https://graph.facebook.com/v8.0/me/messages",
        qs: { access_token: PAGE_ACCESS_TOKEN },
        method: "POST",
        json: request_body
      },
      (err, res, body) => {
        if (!err) {
          resolve(true);
        } else {
          reject(err);
        }
      }
    );
  });
}
