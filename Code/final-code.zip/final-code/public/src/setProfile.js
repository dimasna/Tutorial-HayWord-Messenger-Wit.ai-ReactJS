'use strict';

const e = React.createElement;


function FormInput(props) {
  
  return (
      React.createElement("select", { className: "form-control",onChange: props.handlerLang, value: props.lang, style: { flexGrow: "1", marginTop: '1em'} },
         React.createElement("option", { value: '-' }, "-"),
         React.createElement("option", { value: 'id' }, "Indonesia"),
         React.createElement("option", { value: 'hi' }, "India"),
         React.createElement("option", { value: 'th' }, "Thailand"),
         React.createElement("option", { value: 'en' }, "United States")
      )
    )
}

class Button extends React.Component {
  constructor(props) {
    super(props);
   
    
     this.submit = this.submit.bind(this);
  }
  
  submit () {
    fetch('https://hayword.glitch.me/setProfile', {
  method: 'POST', 
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({id: window.psid, lang: this.props.lang}),
}).then(res => {
      
      
            MessengerExtensions.requestCloseBrowser(function success() {
                console.log("Webview closing");
            }, function error(err) {
                console.log(err);
            });
      
      
    })
  }

  render() {
  
    return e(
      'button',
      { style:{ marginTop: '1em', width: '100%'},className: "btn btn-primary", onClick: this.submit },'Save'
    );
  }
}

class SelectLang extends React.Component {
  constructor(props) {
    super(props);
    this.state = { lang: window.language };
    this.handlerLang = this.handlerLang.bind(this);
  }

  handlerLang (e){
    this.setState({
      lang: e.target.value
    })
  }
  
  render() {
    
    return e(
      'div',
      { style: {display: "flex", flexDirection: "column", alignItems: "center",width: "100%"}, className: "container-fluid" },
        
          React.createElement(FormInput, {lang: this.state.lang, handlerLang: this.handlerLang},null),
          React.createElement(Button, {lang: this.state.lang},null)    
        
    );
  }
}

const dom = document.querySelector('#component');
ReactDOM.render(e(SelectLang), dom);